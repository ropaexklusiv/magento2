<?php

namespace Drupal\Tests\comment\Unit\Migrate\d6;

/**
 * Tests D6 comment source plugin.
 *
 * @group comment
 */
class CommentTest extends CommentTestBase {

}
