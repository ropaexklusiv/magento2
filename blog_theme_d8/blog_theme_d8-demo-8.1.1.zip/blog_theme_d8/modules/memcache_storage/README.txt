===================
## DOCUMENTATION ##
===================

You will find the latest documentation at https://www.drupal.org/node/2099389.


=============
## CREDITS ##
=============

The module was designed & developed by Spleshka (https://www.drupal.org/u/spleshka).
The development wasn't sponsored by anyone. It was created for the love of Drupal.
